public class LeaveRecord_AL extends LeaveRecord {
    public LeaveRecord_AL(String sDay, String eDay) {
        super(sDay, eDay);
        leaveType = "AL";
    }
}
