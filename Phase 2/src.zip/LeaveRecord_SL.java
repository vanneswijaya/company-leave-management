public class LeaveRecord_SL extends LeaveRecord {
    public LeaveRecord_SL(String sDay, String eDay) {
        super(sDay, eDay);
        leaveType = "SL";
    }
}
