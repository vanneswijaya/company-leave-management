public class LeaveRecord_BL extends LeaveRecord {
    public LeaveRecord_BL(String sDay, String eDay) {
        super(sDay, eDay);
        leaveType = "BL";
    }
}
