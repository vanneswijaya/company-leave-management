public class LeaveRecord_NL extends LeaveRecord {
    public LeaveRecord_NL(String sDay, String eDay) {
        super(sDay, eDay);
        leaveType = "NL";
    }
}
