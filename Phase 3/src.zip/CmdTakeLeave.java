public class CmdTakeLeave extends RecordedCommand {
    private Employee e;
    private Company company;
    private String leaveType;
    private String startDay;
    private String endDay;
    private LeaveRecord leaveRecord;
	
	@Override
	public void execute(String[] cmdParts)
	{
		try {
			if (cmdParts.length < 5) {
				throw new ExInsufficientArguments();
			}
			company = Company.getInstance();
			e = company.findEmployee(cmdParts[1]);
            leaveType = cmdParts[2];
            startDay = cmdParts[3];
            endDay = cmdParts[4];

            if (leaveType.equals("AL")) {
                leaveRecord = new LeaveRecord_AL(startDay, endDay);
            } else if (leaveType.equals("BL")) {
                leaveRecord = new LeaveRecord_BL(startDay, endDay);
            }  else if (leaveType.equals("SL")) {
                leaveRecord = new LeaveRecord_SL(startDay, endDay);
            }  else if (leaveType.equals("NL")) {
                leaveRecord = new LeaveRecord_NL(startDay, endDay);
            }

			e.checkOverlappingLeaves(leaveRecord);
			e.checkValidStartLeave(leaveRecord);
			e.checkBalance(leaveRecord);
			e.checkALBL(leaveRecord);
			e.checkValidAL(leaveRecord);
            e.addLeave(leaveRecord);

			addUndoCommand(this);
			clearRedoList();

			System.out.println("Done.");
		} catch (ExInsufficientArguments e) {
			System.out.println(e.getMessage());
		} catch (ExLeaveOverlapped e) {
			System.out.println(e.getMessage());
		} catch (ExInvalidStartLeave e) {
			System.out.println(e.getMessage());
		} catch (ExInsufficientAL e) {
			System.out.println(e.getMessage());
		} catch (ExInsufficientSL e) {
			System.out.println(e.getMessage());
		} catch (ExALType e) {
			System.out.println(e.getMessage());
		} catch (ExBLType e) {
			System.out.println(e.getMessage());
		} catch (ExInvalidAL e) {
			System.out.println(e.getMessage());
		} 
	}
	
	@Override
	public void undoMe()
	{
		e.removeLeave(leaveRecord);
		addRedoCommand(this); //<====== upon undo, we should keep a copy in the redo list (addRedoCommand is implemented in RecordedCommand.java)
	}
	
	@Override
	public void redoMe()
	{
		e.addLeave(leaveRecord);
		addUndoCommand(this); //<====== upon redo, we should keep a copy in the undo list
	}
}
